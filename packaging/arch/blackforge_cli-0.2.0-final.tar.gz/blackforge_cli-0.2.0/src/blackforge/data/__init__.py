"""Bundled BlackArch catalog snapshot."""

